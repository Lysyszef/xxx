const { MessageEmbed } = require("discord.js");

module.exports = (client) => {
    client.on("message", async message => {
        const prefix = process.env?.PREFIX;

        if (message.author.bot) return;
        if (!message.content.startsWith(prefix)) return;
        if (message.guild && message.channel.id !== "1076166463108415488") return message.channel.send(new MessageEmbed()
            .setDescription("Nie możesz używać komend na tym kanale!")
            .setColor("BLUE")
        )

        const args = message.content.slice(prefix.length).trim().split(/ +/g)
        const cmd = args.shift().toLowerCase();
        let command = client.commands.get(cmd);

        if (!command) return;
        if (!command.name) return;

        if (!command) command = client.commands.get(client.aliases.get(cmd));
        if (cmd.length === 0) return;
        if (command) { command.run(client, message, args) }
    })
}