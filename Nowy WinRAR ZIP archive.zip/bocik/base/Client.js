const { Client, Collection } = require("discord.js"),
      { readdir } = require("fs");

class Base extends Client {
    constructor() {
        super();

        this.commands = new Collection();
        this.aliases = new Collection();

        console.log(`Połączono się z botem!`)
    }

    _login(token) {
        super.login(token).then(() => this.user.setActivity({ type: 5, name: "bojówka" }))
        return this;
    }

    _initCommands(path) {
        readdir(path, (err, files) => {
            if (err) console.log(err);

            files.forEach(cmd => {
                const command = new (require(`../${path}/${cmd}`))(this);
                this.commands.set(command.config.name, command);
                command.config.aliases.forEach(a => this.aliases.set(a, command.config.name));
            });
        });

        return this;
    }

    _initEvents(path) {
        readdir(path, (err, files) => {
            if (err) console.log(err);

            files.forEach(events => {
                const event = new (require(`../${path}/${events}`))(this);
                super.on(events.split(".")[0], (...args) => event.run(...args));
            });
        });

        return this;
    }
}

module.exports = Base;